const Cart = require("../models/cartModel");
const Product = require('../models/productModel')

const getCartData = async (req, res) => {
  const cart = await Cart.find({}).sort({ createdAt: -1});
    console.log(cart)
  res.render('cart', { carts: cart})
};


const addToCart = async (req, res) => {
  const prodId = req.params.id


  const product = await Product.findById(prodId)
  const title = product.title;
  const price = product.price;
  const image = product.image;
  const productId = product.id;
  const totalPrice = 0;

  const carts = await Cart.create({ title, price, image, productId, totalPrice })
  console.log(carts)

  res.redirect('/cart')

};

const updateCart = async (req, res) => {
  const { quantity } = req.body;

  const cart = await Cart.findByIdAndUpdate(req.params.id);

  if (!cart) {
    res.status(400).json({ error: "No cart found with this id" });
  }

  await cart.update({ quantity });

  res.redirect('/cart')

};


const removeCartData = async (req, res) => {
  const cartData = await Cart.findById(req.params.id);

  if (!cartData) {
    res.status(400).json("Items not found");
  }

  await cartData.remove();

  
  res.redirect('/cart')
};



const getCheckout = async (req, res) => {
  const prodId = req.params.id

  console.log(prodId)

  const products = await Cart.findById(prodId)

  console.log(products)

  

  res.render('checkout', { products: products })  
}

module.exports = {
  addToCart,
  updateCart,
  getCartData,
  removeCartData,
  getCheckout
};
