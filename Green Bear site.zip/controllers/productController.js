const { mongoose } = require("mongoose");
const Product = require("../models/productModel");

//get all products
const getProducts = async (req, res) => {

  const products = await Product.find({}).sort({ createdAt: -1 })
  
  res.render('products', { products: products})
  console.log(products)
};

//get a single Product
const getProduct = async (req, res) => {
  const { id } = req.params

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({ error: 'Product doesn`t exist.' })
  }

  const product = await Product.findById(id)
   
  if(!product) {
    return res.status(404).json({ error: 'Product doesn`t exist.' })
  }

  res.render('product-detail', { product: product })

};

//create a product(Admin)
const addProduct = async (req, res) => {
  const { title, image, description, price } = req.body;

  const products = await Product.create({ title, image, description, price })
 
  console.log(products)
  // res.redirect('/products')

};

// delete a product(Admin)
const deleteProduct = async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({ error: 'Product doesn`t exist.' })
  }

  const product = await Product.findOneAndDelete({_id: id})
   
  if(!product) {
    return res.status(404).json({ error: 'Product doesn`t exist.' })
  }

  res.status(200).json(product)
};

//update a product(Admin)

const updateProduct = async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(404).json({ error: "Invalid identity" });
  }

  const product = await Product.findByIdAndUpdate(
    { _id: id },
    {
      ...req.body,
    }
  );

  if (!product) {
    return res.status(404).json({ error: "Product does not exist" });
  }

  res.status(200).json(product);
};

module.exports = {
  getProduct,
  getProducts,
  addProduct,
  deleteProduct,
  updateProduct,
};
