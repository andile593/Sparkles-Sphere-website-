const mongoose = require("mongoose");

const cartSchema = new mongoose.Schema({
  title: {
    type: String
  },
  price: {
    type: Number
  },
  image: {
    type: String
  },
  quantity: {
    type: Number,
    default: 1
  },
  productId: {
    type: String
  },
  totalPrice: {
    type: Number
  }
});

module.exports = mongoose.model("Cart", cartSchema);
