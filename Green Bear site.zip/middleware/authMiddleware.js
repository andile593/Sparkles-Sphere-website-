const jwt = require('jsonwebtoken')
const jwtSecret = process.env.JWT

exports.isAdmin = (req, res, next) => {
    const token = req.cookies.jwt;

    if (token) {
        jwt.verify(token, jwtSecret, (err, decodedToken) => {
            if (err) {
                return res.status(401).json({ error: 'Unauthorized'})
                console.log(err.message);
                // res.redirect('/login')
            } else {

                if (decodedToken.role !== 'admin') {
                    return res.status(401).json({ error: 'Unauthorized'})
                } else {
                    next();
                }
                // console.log(decodedToken)
                // next()
            }
        })
    } else {
        res.redirect('/login')
        res.status(401).json({ message: 'Not authorized, token not available'})
    }
    

}

exports.isUser = (req, res, next) => {
    const token = req.cookies.jwt;

    if (token) {
        jwt.verify(token, jwtSecret, (err, decodedToken) => {
            if (err) {
                return res.status(401).json({ error: 'Unauthorized'})
            } else {
                if (decodedToken.role !== 'user') {
                    return res.status(401).json({ error: 'Unauthorized'})
                } else {
                    next();
                }
            }
        })
    } else {
        res.redirect('/signup')
    }
}

