require('dotenv').config()

const express = require('express')
const mongoose = require('mongoose')
const morgan = require('morgan')
const cors = require('cors')
const cookieParser = require('cookie-parser')

//express app
const app = express()



app.set('view engine', 'ejs')
app.set('views', 'views')


//middleware 
app.use(cors({ origin: process.env.REMOTE_CLIENT_APP, credentials: true }))
app.use(express.static('public'))
app.use(morgan('dev'))
app.use(express.urlencoded({ extended: true }));
app.use(express.json())
app.use(cookieParser())


//connect to mongodb
mongoose.connect(process.env.MONGO_URI)
.then(() => {
    app.listen(process.env.PORT, () => {
        console.log('connected to db & listening on port', process.env.PORT);
    })
})
.catch((error) => {
    console.log(error)
})

//routes import 
const products = require('./routes/productRoutes')
const pages = require('./routes/pagesRoutes')
const user = require('./routes/userAuthRoutes')
const cart = require('./routes/cartRoutes')
// const admin = require('./routes/adminRoutes')
const insert = require('./dataImport')



app.use('/',  pages)
app.use('/',  products)
app.use('/', cart)
app.use('/', user)
app.use('/', insert)



// app.listen(process.env.PORT)

