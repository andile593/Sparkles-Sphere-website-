const express = require('express')
const { addToCart, updateCart, getCartData, removeCartData, getCheckout } = require('../controllers/cartController')
const { isUser } = require('../middleware/authMiddleware')

const router = express.Router()


router.get('/cart', getCartData)
router.get('/cart/add-to-cart/:id', addToCart)
router.get('/cart/remove/:id', removeCartData)
router.put('/cart/update/:id', updateCart)
router.get('/checkout/:id', isUser , getCheckout)

module.exports = router;
