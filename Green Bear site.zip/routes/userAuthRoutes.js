const { Router } = require('express')
const { signup_get, signup_post, login_get, login_post, logout_get, updateUser } = require('../controllers/authController')

const router = Router()


router.route('/signup').get(signup_get)
router.route('/signup').post(signup_post)
router.route('/login').get(login_get)
router.route('/login').post(login_post)
router.route('/logout').get(logout_get)

module.exports = router
