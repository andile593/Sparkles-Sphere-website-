const express = require('express')
const { getProducts, getProduct, addProduct, deleteProduct, updateProduct } = require('../controllers/productController')
const { isAdmin } = require('../middleware/authMiddleware')
const router = express.Router()


//GET all products
router.route('/products').get(getProducts)
router.route('/products/create').post(addProduct)
router.route('/products/:id').get(getProduct)
router.route('/products/:id').delete(deleteProduct)
router.route('/products/:id').put(updateProduct)

module.exports = router